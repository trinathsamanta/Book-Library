import React, { Component } from 'react'

export default class contact extends Component {
    render() {
        return (
            <div>
                YOU CAN CONTACT US
            </div>
        )
    }
}
