export const FETCH_DATA = "FETCH_DATA"

export const fetchdata = (value) =>({
    type:FETCH_DATA,
    payload: value
})