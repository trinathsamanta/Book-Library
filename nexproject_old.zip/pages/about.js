import React, { Component } from 'react'

export default class about extends Component {
    render() {
        return (
            <div>
                About us
            </div>
        )
    }
}
